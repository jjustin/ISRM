public abstract class Runner {
    public abstract Solution run(Graph g);
}
