public class Globals {
    public static double crossoverRate = 0;
    public static double mutateScalar = 0;
    public static int popSize = 20;
    public static int numberOfIters = 400;

    // problem specific info
    public static int nOfSites;
    public static int maxWeigth;
    public static int trashType = 1;
}
