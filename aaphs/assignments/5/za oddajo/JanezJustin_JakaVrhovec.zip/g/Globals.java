public class Globals {
    // problem specific info
    public static int nOfSites;
    public static int maxWeigth;
    public static int trashType = 1;
}
