public abstract class Starter {
    public abstract Solution generateStarting(Graph g);
}
