#include "dep.h"
int main()
{
   // printf() displays the string inside quotation
   hello_printer();
   return 0;
}
