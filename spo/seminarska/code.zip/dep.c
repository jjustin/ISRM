#include <stdio.h>
void hello_printer()
{
    printf("Hello, World!");
}
